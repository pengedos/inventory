-keepattributes JavascriptInterface
-keepclassmembers class com.sikat.araw.inventory.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.sikat.araw.inventory.** { *; }
